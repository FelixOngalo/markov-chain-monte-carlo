function lp = log_post_regression(theta, X, y, V0, a0, b0)
%LOG_POST_REGRESSION Log posterior (up to a constant) of theta = [beta; log(s2)] for the
%   conjugate Bayesian linear regression, including the Jacobian of the log transform.
p = size(X, 2); n = size(X, 1);
beta = theta(1:p); u = theta(p + 1); s2 = exp(u);
res = y - X * beta;
loglik = -0.5 * n * log(s2) - 0.5 * (res' * res) / s2;
logprior_beta = -0.5 * p * log(s2) - 0.5 * (beta' * (V0 \ beta)) / s2;
logprior_s2 = -(a0 + 1) * u - b0 / s2;
lp = loglik + logprior_beta + logprior_s2 + u;     % + u: Jacobian of s2 = exp(u)
end
