function out = summarise_modes(C3, scale, acc, swap)
%SUMMARISE_MODES Diagnostics for a bimodal target sampled by several chains.
%   C3 is an N-by-nchains-by-d array of draws. The mode of a draw is the sign of its coordinate sum.
%   Returns [scale, acceptance, swap_rate, rhat(x1), ess(x1), min chain share in + mode,
%            max chain share in + mode, mode switches per chain, pooled share in + mode].
x1 = C3(:, :, 1);
sgn = sign(squeeze(sum(C3, 3)));                 % N-by-nchains
share = mean(sgn > 0, 1);                        % per-chain share of time in the + mode
switches = mean(sum(abs(diff(sgn, 1, 1)) > 0, 1));
out = [scale, acc, swap, rhat(x1), ess(x1), min(share), max(share), switches, mean(sgn(:) > 0)];
end
