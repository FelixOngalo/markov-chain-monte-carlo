function r = autocorr_fft(x)
%AUTOCORR_FFT Sample autocorrelation r(k+1) at lags k = 0..n-1 (biased estimator, via FFT).
x = x(:) - mean(x); n = numel(x);
nfft = 2^nextpow2(2 * n);
f = fft(x, nfft);
acov = real(ifft(f .* conj(f)));
acov = acov(1:n) / n;
if acov(1) == 0, r = [1; zeros(n - 1, 1)]; else, r = acov / acov(1); end
end
