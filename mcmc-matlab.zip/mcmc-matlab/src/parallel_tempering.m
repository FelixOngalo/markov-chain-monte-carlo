function [Xcold, swap_rate] = parallel_tempering(logpdf, x0, N, betas, scales)
%PARALLEL_TEMPERING Replica-exchange MCMC for multimodal targets.
%   Chain k targets pi(x)^betas(k) (betas(1) = 1 is the cold chain we keep).
%   Each iteration: one random-walk Metropolis update per temperature (step scales(k)),
%   then a proposed swap of the states of a random adjacent pair (k, k+1), accepted with
%   probability min(1, exp((betas(k) - betas(k+1)) * (logpi(x_{k+1}) - logpi(x_k)))).
K = numel(betas); d = numel(x0);
Xs = repmat(x0(:)', K, 1);
lp = zeros(K, 1);
for k = 1:K, lp(k) = logpdf(Xs(k, :)'); end
Xcold = zeros(N, d); swaps = 0;
for t = 1:N
    for k = 1:K
        y = Xs(k, :)' + scales(k) * randn(d, 1);
        lpy = logpdf(y);
        if log(rand) < betas(k) * (lpy - lp(k))
            Xs(k, :) = y'; lp(k) = lpy;
        end
    end
    k = randi(K - 1);
    if log(rand) < (betas(k) - betas(k + 1)) * (lp(k + 1) - lp(k))
        tmpx = Xs(k, :); Xs(k, :) = Xs(k + 1, :); Xs(k + 1, :) = tmpx;
        tmpl = lp(k); lp(k) = lp(k + 1); lp(k + 1) = tmpl;
        swaps = swaps + 1;
    end
    Xcold(t, :) = Xs(1, :);
end
swap_rate = swaps / N;
end
