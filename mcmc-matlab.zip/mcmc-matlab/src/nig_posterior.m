function post = nig_posterior(X, y, V0, a0, b0)
%NIG_POSTERIOR Exact posterior of the conjugate Bayesian linear regression.
%   Model: y = X*beta + e, e ~ N(0, s2 I); prior beta | s2 ~ N(0, s2*V0), s2 ~ InvGamma(a0, b0).
%   Posterior: beta | s2, y ~ N(m, s2*Vn), s2 | y ~ InvGamma(an, bn) with
%     Vn = (inv(V0) + X'X)^-1,  m = Vn X'y,  an = a0 + n/2,  bn = b0 + (y'y - m' inv(Vn) m)/2.
%   Marginals: E[beta|y] = m, Cov[beta|y] = bn/(an-1) Vn, E[s2|y] = bn/(an-1),
%   Var[s2|y] = bn^2 / ((an-1)^2 (an-2)).
n = size(X, 1);
Vn = inv(inv(V0) + X' * X); Vn = (Vn + Vn') / 2;
m = Vn * (X' * y);
an = a0 + n / 2;
bn = b0 + 0.5 * (y' * y - m' * (Vn \ m));
post.Vn = Vn; post.m = m; post.an = an; post.bn = bn;
post.beta_mean = m;
post.beta_cov = bn / (an - 1) * Vn;
post.beta_sd = sqrt(diag(post.beta_cov));
post.s2_mean = bn / (an - 1);
post.s2_sd = sqrt(bn^2 / ((an - 1)^2 * (an - 2)));
end
