function tau = iact(x)
%IACT Integrated autocorrelation time tau = 1 + 2*sum_k rho_k of a scalar chain.
%   Uses Geyer's initial positive sequence: add the pair sums
%   G_m = rho_{2m} + rho_{2m+1} until the first negative one.
%   Effective sample size is N / tau.
x = x(:); n = numel(x);
r = autocorr_fft(x);
tau = -1; m = 0;
while 2 * m + 2 <= n
    g = r(2 * m + 1) + r(2 * m + 2);       % lags 2m and 2m+1
    if g < 0, break; end
    tau = tau + 2 * g;
    m = m + 1;
end
tau = max(tau, 1 / n);
end
