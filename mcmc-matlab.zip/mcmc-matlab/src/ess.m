function e = ess(x)
%ESS Effective sample size of one scalar chain, or the sum over the columns of a matrix of chains.
e = 0;
for j = 1:size(x, 2)
    e = e + size(x, 1) / iact(x(:, j));
end
end
