function write_csv(file, header, M)
%WRITE_CSV Write a numeric matrix to a CSV file with a header row (cell array of names).
fid = fopen(file, 'w');
fprintf(fid, '%s\n', strjoin(header, ','));
fmt = [repmat('%.10g,', 1, size(M, 2) - 1), '%.10g\n'];
fprintf(fid, fmt, M');
fclose(fid);
end
