function [X, acc_rate, logp] = mh_sampler(logpdf, x0, N, L)
%MH_SAMPLER Random-walk Metropolis sampler.
%   [X, acc_rate, logp] = mh_sampler(logpdf, x0, N, L)
%   logpdf : handle returning the log of the (unnormalised) target density at a column vector
%   x0     : starting point (column vector)
%   N      : number of iterations
%   L      : proposal factor: y = x + L*z with z ~ N(0, I). Pass a scalar s for isotropic
%            steps (covariance s^2*I) or a lower-triangular matrix for covariance L*L'.
%   X      : N-by-d matrix of states (state after each iteration)
%   acc_rate : fraction of accepted proposals
%   logp   : log-density of the state at each iteration
x = x0(:); d = numel(x);
X = zeros(N, d); logp = zeros(N, 1);
lp = logpdf(x); accepted = 0;
for t = 1:N
    z = randn(d, 1);
    y = x + L * z;
    lpy = logpdf(y);
    if log(rand) < lpy - lp
        x = y; lp = lpy; accepted = accepted + 1;
    end
    X(t, :) = x'; logp(t) = lp;
end
acc_rate = accepted / N;
end
