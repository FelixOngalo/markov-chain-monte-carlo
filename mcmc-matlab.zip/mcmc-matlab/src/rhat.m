function R = rhat(chains)
%RHAT Split potential scale reduction factor (Gelman-Rubin) for an n-by-m matrix (columns = chains).
%   Each chain is split in two halves so that non-stationarity within a chain is also detected.
n = size(chains, 1);
h = floor(n / 2);
sp = [chains(1:h, :), chains(h + 1:2 * h, :)];
mj = mean(sp, 1);                         % chain means
sj2 = var(sp, 0, 1);                      % chain variances
W = mean(sj2);                            % within-chain variance
B = h * var(mj(:));                       % between-chain variance
vhat = (h - 1) / h * W + B / h;           % pooled variance estimate
R = sqrt(vhat / W);
end
