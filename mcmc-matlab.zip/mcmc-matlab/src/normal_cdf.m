function p = normal_cdf(z)
%NORMAL_CDF Standard normal cumulative distribution function (core MATLAB, no toolbox).
p = 0.5 * erfc(-z / sqrt(2));
end
