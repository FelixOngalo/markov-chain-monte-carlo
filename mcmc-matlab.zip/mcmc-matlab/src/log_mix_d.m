function lp = log_mix_d(x)
%LOG_MIX_D Log density of the equal mixture 0.5*N(mu*1, I) + 0.5*N(-mu*1, I) in d dimensions
%   with mu = 2.5 per coordinate (distance between the two modes: 2*2.5*sqrt(d), about 16 standard
%   deviations when d = 10), computed stably.
mu = 2.5; d = numel(x);
a = -0.5 * sum((x - mu).^2); b = -0.5 * sum((x + mu).^2);
m = max(a, b);
lp = m + log(0.5 * exp(a - m) + 0.5 * exp(b - m)) - 0.5 * d * log(2 * pi);
end
