function X = gibbs_bivariate(rho, N, x0)
%GIBBS_BIVARIATE Gibbs sampler for a standard bivariate normal with correlation rho.
%   Full conditionals: x | y ~ N(rho*y, 1 - rho^2) and y | x ~ N(rho*x, 1 - rho^2).
%   The x-coordinate of this chain is exactly an AR(1) process with coefficient rho^2.
s = sqrt(1 - rho^2);
x = x0(1); y = x0(2);
X = zeros(N, 2);
for t = 1:N
    x = rho * y + s * randn;
    y = rho * x + s * randn;
    X(t, :) = [x, y];
end
end
