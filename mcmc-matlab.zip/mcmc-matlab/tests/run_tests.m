% RUN_TESTS  Unit tests with known answers. Stops with an error if any check fails.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src'));
rng(11); nfail = 0;
check = @(cond, msg) assert(cond, msg);

% 1. iid draws: tau close to 1, ESS close to N
x = randn(100000, 1);
check(abs(iact(x) - 1) < 0.1, 'iact of iid noise should be about 1');

% 2. AR(1) with phi = 0.8: tau = (1 + phi)/(1 - phi) = 9
phi = 0.8; n = 200000; z = randn(n, 1); a = zeros(n, 1);
for t = 2:n, a(t) = phi * a(t - 1) + z(t); end
check(abs(iact(a) - 9) / 9 < 0.12, 'iact of AR(1) should be near 9');

% 3. R-hat: about 1 for chains from the same distribution, large for separated chains
check(rhat(randn(5000, 4)) < 1.02, 'rhat of iid chains should be near 1');
check(rhat(randn(5000, 4) + repmat([0, 3, 6, 9], 5000, 1)) > 1.5, 'rhat of separated chains should be large');

% 4. Random-walk Metropolis recovers N(0,1) moments
[X, acc] = mh_sampler(@(x) -0.5 * x^2, 0, 100000, 2.4);
check(abs(mean(X)) < 0.05 && abs(var(X) - 1) < 0.07, 'mh_sampler moments for N(0,1)');
check(acc > 0.3 && acc < 0.5, 'mh_sampler acceptance rate for N(0,1) with step 2.4');

% 5. Gibbs sampler: correlation and marginal variance
G = gibbs_bivariate(0.7, 200000, [0; 0]);
c = corrcoef(G); check(abs(c(1, 2) - 0.7) < 0.02 && abs(var(G(:, 1)) - 1) < 0.03, 'gibbs_bivariate moments');

% 6. Acceptance lemma: E[min(1, exp(W))] = 2 Phi(-sigma/2)
s = 2; W = -s^2 / 2 + s * randn(2000000, 1);
check(abs(mean(min(1, exp(W))) - 2 * normal_cdf(-s / 2)) < 0.003, 'acceptance lemma');

% 7. Exact posterior of the regression model: matches the closed form for the one-parameter case
n = 5; x = (1:n)'; yv = [1.1; 1.9; 3.2; 3.9; 5.1]; V0 = 4; a0 = 3; b0 = 2;
pst = nig_posterior(x, yv, V0, a0, b0);
Vn = 1 / (1 / V0 + x' * x); m = Vn * (x' * yv);
check(abs(pst.m - m) < 1e-12 && abs(pst.bn - (b0 + 0.5 * (yv' * yv - m^2 / Vn))) < 1e-12, 'nig_posterior closed form');

% 8. The log posterior is a proper density: its Metropolis output reproduces the exact posterior mean
Xr = [ones(50, 1), randn(50, 1)]; yr = Xr * [1; -2] + randn(50, 1);
V0 = 10 * eye(2); a0 = 2; b0 = 2;
pr = nig_posterior(Xr, yr, V0, a0, b0);
lpf = @(th) log_post_regression(th, Xr, yr, V0, a0, b0);
th0 = [Xr \ yr; 0];
[Xs, ~] = mh_sampler(lpf, th0, 60000, 0.12);
check(max(abs(mean(Xs(10001:end, 1:2))' - pr.beta_mean)) < 0.08, 'MCMC posterior mean of beta versus exact');

disp('All tests passed.');
