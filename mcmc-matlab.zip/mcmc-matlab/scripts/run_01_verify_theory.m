% RUN_01_VERIFY_THEORY  Numerical checks of three results proved in the report.
%   (a) the Metropolis-Hastings kernel satisfies detailed balance (exactly, on a 5-state space);
%   (b) the integrated autocorrelation time of a Gibbs chain equals (1+rho^2)/(1-rho^2), and the
%       variance of a chain average is sigma^2 * tau / N;
%   (c) E[min(1, exp(W))] = 2*Phi(-sigma/2) for W ~ N(-sigma^2/2, sigma^2).
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src')); outdir = fullfile(root, 'results');
if ~exist(outdir, 'dir'), mkdir(outdir); end
rng(1);

%% (a) Exact Metropolis-Hastings kernel on a finite state space
K = 5;
target = rand(K, 1); target = target / sum(target);
Q = rand(K, K); Q = Q ./ sum(Q, 2);                 % a non-symmetric proposal kernel
P = zeros(K, K);
for i = 1:K
    for j = 1:K
        if i ~= j
            alpha = min(1, (target(j) * Q(j, i)) / (target(i) * Q(i, j)));
            P(i, j) = Q(i, j) * alpha;
        end
    end
    P(i, i) = 1 - sum(P(i, :));
end
stationarity_gap = max(abs(target' * P - target'));
db_gap = max(max(abs(diag(target) * P - (diag(target) * P)')));
ev = sort(abs(eig(P)), 'descend');
lambda2 = ev(2);
% distance to the target from state 1, versus lambda2^t
tv = zeros(21, 1); mu = [1, zeros(1, K - 1)];
for t = 0:20, tv(t + 1) = 0.5 * sum(abs(mu - target')); mu = mu * P; end
fprintf('(a) stationarity gap %.2e, detailed-balance gap %.2e, second eigenvalue modulus %.4f\n', stationarity_gap, db_gap, lambda2);
write_csv(fullfile(outdir, 'mh_kernel_check.csv'), {'stationarity_gap', 'detailed_balance_gap', 'lambda2'}, [stationarity_gap, db_gap, lambda2]);
write_csv(fullfile(outdir, 'mh_kernel_tv.csv'), {'t', 'tv_distance', 'lambda2_power'}, [(0:20)', tv, lambda2 .^ (0:20)']);

%% (b) Integrated autocorrelation time of the Gibbs sampler
rhos = [0.5, 0.9, 0.99];
N = 500000; R = 1000; n = 4000;
res = zeros(numel(rhos), 6);
for q = 1:numel(rhos)
    rho = rhos(q);
    tau_theory = (1 + rho^2) / (1 - rho^2);
    X = gibbs_bivariate(rho, N, randn(2, 1));
    tau_hat = iact(X(:, 1));
    means = zeros(R, 1);
    for r = 1:R
        Z = gibbs_bivariate(rho, n, randn(2, 1));     % start in stationarity (each marginal is N(0,1))
        means(r) = mean(Z(:, 1));
    end
    res(q, :) = [rho, tau_theory, tau_hat, var(means), tau_theory / n, var(means) / (tau_theory / n)];
    fprintf('(b) rho=%.2f: tau theory %.2f, estimated %.2f; var of mean %.3e vs sigma^2*tau/n %.3e\n', rho, tau_theory, tau_hat, var(means), tau_theory / n);
end
write_csv(fullfile(outdir, 'gibbs_iact.csv'), {'rho', 'tau_theory', 'tau_estimated', 'var_of_mean_empirical', 'var_of_mean_theory', 'ratio'}, res);

%% (c) Expected acceptance probability for a Gaussian log-ratio
sigmas = [0.5, 1, 2, 3];
lem = zeros(numel(sigmas), 3);
for q = 1:numel(sigmas)
    s = sigmas(q);
    W = -s^2 / 2 + s * randn(2000000, 1);
    lem(q, :) = [s, mean(min(1, exp(W))), 2 * normal_cdf(-s / 2)];
end
disp(lem);
write_csv(fullfile(outdir, 'acceptance_lemma.csv'), {'sigma', 'monte_carlo', 'formula_2Phi'}, lem);
