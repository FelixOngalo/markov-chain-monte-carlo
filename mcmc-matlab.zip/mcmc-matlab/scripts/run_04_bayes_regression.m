% RUN_04_BAYES_REGRESSION  Bayesian linear regression with unknown noise variance. The conjugate
%   prior makes the exact posterior available, so Metropolis output can be graded against it.
%   Compares isotropic proposals with proposals that use the posterior covariance (estimated from a pilot run).
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src')); outdir = fullfile(root, 'results'); figdir = fullfile(outdir, 'figures');
if ~exist(figdir, 'dir'), mkdir(figdir); end
rng(4);

% Data with known truth
n = 100; p = 4; d = p + 1;
Z = randn(n, p - 1);
Z(:, 3) = 0.95 * Z(:, 2) + sqrt(1 - 0.95^2) * Z(:, 3);       % two strongly correlated predictors: posterior of their coefficients is elongated
X = [ones(n, 1), Z];
beta_true = [1; 2; -1; 0.5]; sigma_true = 1.5;
y = X * beta_true + sigma_true * randn(n, 1);
V0 = 10 * eye(p); a0 = 2; b0 = 2;
post = nig_posterior(X, y, V0, a0, b0);
logpost = @(th) log_post_regression(th, X, y, V0, a0, b0);

% Pilot run with a small isotropic step to estimate the posterior covariance
beta_ols = X \ y; s2_ols = sum((y - X * beta_ols).^2) / (n - p);
theta0 = [beta_ols; log(s2_ols)];
[Xp, ~] = mh_sampler(logpost, theta0, 6000, 0.03);
Cp = cov(Xp(3001:end, :));
Ltuned = (2.38 / sqrt(d)) * chol(Cp, 'lower');
Liso = 0.08;                                        % an isotropic step of sensible size

N = 20000; burn = 2000; nch = 4;
labels = {'beta1', 'beta2', 'beta3', 'beta4', 'sigma2'};
runs = struct('name', {'isotropic', 'covariance_tuned'}, 'L', {Liso, Ltuned});
summary = zeros(2 * d, 9); row = 0; chains_out = [];
for r = 1:2
    chains = zeros(N - burn, nch, d); acc = zeros(1, nch);
    for c = 1:nch
        start = theta0 + 0.3 * randn(d, 1);
        [Xc, acc(c)] = mh_sampler(logpost, start, N, runs(r).L);
        Xc = Xc(burn + 1:end, :); Xc(:, d) = exp(Xc(:, d));        % report sigma^2 rather than log sigma^2
        chains(:, c, :) = reshape(Xc, N - burn, 1, d);
    end
    fprintf('%s proposals: acceptance %.3f\n', runs(r).name, mean(acc));
    exact_mean = [post.beta_mean; post.s2_mean]; exact_sd = [post.beta_sd; post.s2_sd];
    for j = 1:d
        cj = chains(:, :, j);
        m = mean(cj(:)); e = ess(cj); sdj = std(cj(:));
        z = (m - exact_mean(j)) / (exact_sd(j) / sqrt(e));
        row = row + 1;
        summary(row, :) = [r, j, m, exact_mean(j), sdj, exact_sd(j), rhat(cj), e, z];
        fprintf('  %-6s mean %.4f (exact %.4f), sd %.4f (exact %.4f), R-hat %.3f, ESS %.0f, z %.2f\n', labels{j}, m, exact_mean(j), sdj, exact_sd(j), rhat(cj), e, z);
    end
    if r == 2    % keep the tuned chains for the R cross-check
        for c = 1:nch
            chains_out = [chains_out; c * ones(N - burn, 1), (1:N - burn)', squeeze(chains(:, c, :))]; %#ok<AGROW>
        end
    end
end
write_csv(fullfile(outdir, 'regression_summary.csv'), {'proposal_1iso_2tuned', 'parameter_index', 'mcmc_mean', 'exact_mean', 'mcmc_sd', 'exact_sd', 'rhat', 'ess', 'z_score_mean'}, summary);
write_csv(fullfile(outdir, 'chains_regression.csv'), [{'chain', 'iter'}, labels], chains_out);

% Truth versus posterior (one line per parameter)
cover = zeros(d, 4); truth = [beta_true; sigma_true^2];
lo = [post.beta_mean - 1.96 * post.beta_sd; 0]; hi = [post.beta_mean + 1.96 * post.beta_sd; 0];
for j = 1:p, cover(j, :) = [j, truth(j), lo(j), hi(j)]; end
write_csv(fullfile(outdir, 'regression_truth_vs_posterior.csv'), {'parameter_index', 'truth', 'approx_ci_low', 'approx_ci_high'}, cover(1:p, :));

fig = figure('Visible', 'off');
sel = find(chains_out(:, 1) == 1);
subplot(2, 2, 1); plot(chains_out(sel, 4)); title('Trace of \beta_2 (tuned, chain 1)'); xlabel('iteration');
subplot(2, 2, 2); hist(chains_out(:, 4), 50); title('Posterior of \beta_2 (all chains)');
subplot(2, 2, 3); hist(chains_out(:, 7), 50); title('Posterior of \sigma^2 (all chains)');
subplot(2, 2, 4); a = autocorr_fft(chains_out(sel, 4)); plot(0:60, a(1:61)); title('Autocorrelation of \beta_2'); xlabel('lag'); grid on;
saveas(fig, fullfile(figdir, 'regression_posterior.png')); close(fig);
