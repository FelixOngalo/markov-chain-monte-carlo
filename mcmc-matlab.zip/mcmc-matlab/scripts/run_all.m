% RUN_ALL  Run the tests and the four experiments (about a few minutes in core MATLAB).
root = fileparts(fileparts(mfilename('fullpath')));
run(fullfile(root, 'tests', 'run_tests.m'));
run(fullfile(root, 'scripts', 'run_01_verify_theory.m'));
run(fullfile(root, 'scripts', 'run_02_scaling_acceptance.m'));
run(fullfile(root, 'scripts', 'run_03_multimodal.m'));
run(fullfile(root, 'scripts', 'run_04_bayes_regression.m'));
disp('Done. Results are in the results/ folder.');
