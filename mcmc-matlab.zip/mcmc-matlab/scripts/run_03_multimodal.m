% RUN_03_MULTIMODAL  A bimodal target in 10 dimensions: 0.5 N(+2.5*1, I) + 0.5 N(-2.5*1, I).
%   The modes are about 16 standard deviations apart. A random-walk sampler tuned for one mode never
%   leaves it. Per-chain effective sample sizes look healthy, and only the between-chain diagnostic
%   (R-hat) reveals the problem. Parallel tempering moves between the modes.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src')); outdir = fullfile(root, 'results'); figdir = fullfile(outdir, 'figures');
if ~exist(figdir, 'dir'), mkdir(figdir); end
rng(3);

d = 10; N = 40000; nch = 4;
starts = [-3, -2, 2, 3];                          % two chains start near each mode
scales = [0.4, 0.75, 1.5, 3];                     % 0.75 is about 2.38/sqrt(d), the within-mode optimum
res = zeros(numel(scales) + 1, 9);
keepRW = []; keepPT = [];


for q = 1:numel(scales)
    C3 = zeros(N, nch, d); acc = zeros(1, nch);
    for c = 1:nch
        [Xc, acc(c)] = mh_sampler(@log_mix_d, starts(c) * ones(d, 1), N, scales(q));
        C3(:, c, :) = reshape(Xc, N, 1, d);
    end
    res(q, :) = summarise_modes(C3, scales(q), mean(acc), NaN);
    fprintf('RW scale %.2f: acceptance %.2f, R-hat %.3f, ESS(x1) %.0f, share in + mode per chain [%.2f, %.2f], mode switches per chain %.1f\n', ...
            res(q, 1), res(q, 2), res(q, 4), res(q, 5), res(q, 6), res(q, 7), res(q, 8));
    if scales(q) == 0.75, keepRW = squeeze(C3(:, :, 1)); end
end

% Parallel tempering: 10 temperatures from 1 down to 0.03 (geometric), step sizes growing like 1/sqrt(beta)
K = 10; betas = 0.03 .^ ((0:K - 1) / (K - 1)); pt_scales = 0.75 ./ sqrt(betas);
C3 = zeros(N, nch, d); sw = zeros(1, nch);
for c = 1:nch
    [Xc, sw(c)] = parallel_tempering(@log_mix_d, starts(c) * ones(d, 1), N, betas, pt_scales);
    C3(:, c, :) = reshape(Xc, N, 1, d);
end
res(end, :) = summarise_modes(C3, NaN, NaN, mean(sw));
fprintf('Parallel tempering: R-hat %.3f, ESS(x1) %.0f, share in + mode per chain [%.2f, %.2f], mode switches per chain %.1f, swap acceptance %.2f\n', ...
        res(end, 4), res(end, 5), res(end, 6), res(end, 7), res(end, 8), res(end, 3));
keepPT = squeeze(C3(:, :, 1));
write_csv(fullfile(outdir, 'multimodal_results.csv'), {'rw_scale', 'acceptance', 'pt_swap_rate', 'rhat_x1', 'ess_x1_total', ...
          'min_chain_share_plus_mode', 'max_chain_share_plus_mode', 'mode_switches_per_chain', 'pooled_share_plus_mode'}, res);

fig = figure('Visible', 'off');
subplot(2, 2, 1); plot(keepRW); title('Random walk (scale 0.75): coordinate 1, four chains'); xlabel('iteration');
subplot(2, 2, 2); plot(keepPT); title('Parallel tempering: coordinate 1, four chains'); xlabel('iteration');
subplot(2, 2, 3); hist(keepRW(:), 60); title('Random walk: all draws');
subplot(2, 2, 4); hist(keepPT(:), 60); title('Parallel tempering: all draws');
saveas(fig, fullfile(figdir, 'multimodal.png')); close(fig);
