% RUN_02_SCALING_ACCEPTANCE  Random-walk Metropolis on a 50-dimensional standard normal.
%   Proposal N(x, (ell^2/d) I). Theory (Roberts, Gelman and Gilks 1997): as d grows the acceptance
%   rate tends to 2*Phi(-ell/2) and the efficiency is proportional to ell^2 * 2*Phi(-ell/2), which
%   peaks at ell = 2.38 with acceptance 0.234.
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'src')); outdir = fullfile(root, 'results'); figdir = fullfile(outdir, 'figures');
if ~exist(figdir, 'dir'), mkdir(figdir); end
rng(2);

d = 50; N = 50000; reps = 3;
ells = (0.5:0.25:5)';
logp = @(x) -0.5 * (x' * x);
out = zeros(numel(ells), 7);
for q = 1:numel(ells)
    ell = ells(q); s = ell / sqrt(d);
    acc = zeros(reps, 1); esjd = zeros(reps, 1); ess1 = zeros(reps, 1); esst = zeros(reps, 1);
    for r = 1:reps
        [X, acc(r)] = mh_sampler(logp, randn(d, 1), N, s);          % start in stationarity
        esjd(r) = mean(sum(diff(X).^2, 2)) / d;                      % mean squared jump per coordinate
        ess1(r) = ess(X(:, 1));
        esst(r) = ess(sum(X.^2, 2));                                 % slowest-mixing statistic: |x|^2
    end
    out(q, :) = [ell, mean(acc), 2 * normal_cdf(-ell / 2), mean(esjd), mean(ess1) / N, mean(esst) / N, ell^2 * 2 * normal_cdf(-ell / 2)];
    fprintf('ell %.2f: acceptance %.3f (theory %.3f), ESS/N for x1 %.3f, for |x|^2 %.3f\n', ell, out(q, 2), out(q, 3), out(q, 5), out(q, 6));
end
write_csv(fullfile(outdir, 'scaling_results.csv'), {'ell', 'acceptance', 'acceptance_theory', 'esjd_per_coordinate', 'ess_per_iter_x1', 'ess_per_iter_normsq', 'efficiency_theory_unnormalised'}, out);

% Theoretical optimum
[ell_star, negval] = fminbnd(@(l) -l^2 * 2 * normal_cdf(-l / 2), 0.5, 5);
a_star = 2 * normal_cdf(-ell_star / 2);
[~, i1] = max(out(:, 5)); [~, i2] = max(out(:, 6)); [~, i3] = max(out(:, 4));
fprintf('Theory optimum: ell = %.3f, acceptance %.3f\n', ell_star, a_star);
fprintf('Empirical optimum (ESS of x1): ell = %.2f, acceptance %.3f; (ESS of |x|^2): ell = %.2f, acceptance %.3f; (ESJD): ell = %.2f, acceptance %.3f\n', ...
        out(i1, 1), out(i1, 2), out(i2, 1), out(i2, 2), out(i3, 1), out(i3, 2));
write_csv(fullfile(outdir, 'scaling_optimum.csv'), {'theory_ell', 'theory_acceptance', 'emp_ell_x1', 'emp_acc_x1', 'emp_ell_normsq', 'emp_acc_normsq', 'emp_ell_esjd', 'emp_acc_esjd'}, ...
          [ell_star, a_star, out(i1, 1), out(i1, 2), out(i2, 1), out(i2, 2), out(i3, 1), out(i3, 2)]);

fig = figure('Visible', 'off');
subplot(1, 2, 1); plot(out(:, 1), out(:, 2), 'o', out(:, 1), out(:, 3), '-'); xlabel('\ell'); ylabel('acceptance rate'); legend('simulation (d = 50)', '2\Phi(-\ell/2)'); grid on;
subplot(1, 2, 2); plot(out(:, 2), out(:, 5), 'o-', out(:, 2), out(:, 6), 's-'); xlabel('acceptance rate'); ylabel('ESS per iteration'); legend('x_1', '|x|^2'); grid on;
saveas(fig, fullfile(figdir, 'scaling_acceptance.png')); close(fig);
