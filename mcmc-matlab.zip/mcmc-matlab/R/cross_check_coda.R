# Cross-check of the MATLAB diagnostics with the R package coda.
# Run after scripts/run_04_bayes_regression.m has written results/chains_regression.csv.
# install.packages("coda")  # if needed
library(coda)

chains <- read.csv("results/chains_regression.csv")
params <- setdiff(names(chains), c("chain", "iter"))
mcmc_list <- mcmc.list(lapply(split(chains, chains$chain), function(df) mcmc(df[, params])))

ess_coda  <- effectiveSize(mcmc_list)
rhat_coda <- gelman.diag(mcmc_list, autoburnin = FALSE, multivariate = FALSE)$psrf[, "Point est."]

matlab <- read.csv("results/regression_summary.csv")
matlab <- matlab[matlab$proposal_1iso_2tuned == 2, ]          # the covariance-tuned run is the one exported
comparison <- data.frame(
  parameter   = params,
  ess_matlab  = matlab$ess,
  ess_coda    = as.numeric(ess_coda[params]),
  rhat_matlab = matlab$rhat,
  rhat_coda   = as.numeric(rhat_coda[params]))
comparison$ess_ratio <- comparison$ess_coda / comparison$ess_matlab
print(comparison, digits = 4)
write.csv(comparison, "results/coda_check.csv", row.names = FALSE)

# The two ESS estimators differ (spectral-density fit in coda, initial positive sequence in MATLAB),
# so agreement within roughly 30% is expected. coda's R-hat is not split-chain, so R-hat values should agree
# closely but not exactly.
