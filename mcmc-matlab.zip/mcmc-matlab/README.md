# MCMC from First Principles: Theory, Proofs and a MATLAB Implementation

An applied and statistical mathematics project written in MATLAB (core only, no
toolboxes). It implements random-walk Metropolis, a Gibbs sampler, parallel
tempering and convergence diagnostics from scratch, proves the theory behind
them, and checks each result numerically against exact answers. A short R script
cross-checks the diagnostics with the `coda` package.

## Question

Why do Metropolis-Hastings and Gibbs samplers converge to the right
distribution, how fast and how reliably do they do so, how should the step size
be chosen, and how do you detect (and fix) a sampler that is stuck?

## Key findings

*(Fill in after running: agreement of estimated and exact autocorrelation times,
optimal step size and acceptance rate versus 2.38 and 0.234, what R-hat showed
on the bimodal target, and how closely MCMC matched the exact regression posterior.)*

## What is in it

- **Validity:** proof that Metropolis-Hastings satisfies detailed balance, with an
  exact check on a 5-state space
- **Accuracy:** integrated autocorrelation time and effective sample size; exact
  formula tau = (1 + rho^2) / (1 - rho^2) for the bivariate-normal Gibbs sampler,
  verified by simulation
- **Step size:** proof of the acceptance-rate formula 2 Phi(-l/2) and numerical
  study of the 0.234 rule in 50 dimensions
- **Diagnostics:** split R-hat and ESS written from scratch, and the demonstration
  that per-chain ESS can look healthy while chains are stuck in different modes
- **Multimodality:** a 10-dimensional bimodal target where random walks fail and
  parallel tempering succeeds, with a proof that the swap move is valid
- **Application:** Bayesian linear regression with correlated predictors, graded
  against the exact conjugate posterior; covariance-tuned versus isotropic
  proposals

## Tools

MATLAB (core functions only: `randn`, `fft`, `chol`, `eig`, `erfc`, `fminbnd`).
R with the `coda` package for the cross-check.

## Reproduce

1. In MATLAB, set the current folder to the project root and run `scripts/run_all.m`
   (runs `tests/run_tests.m` first, then the four experiments; allow a few minutes)
2. Results appear in `results/` (CSV files) and `results/figures/` (PNG files)
3. Optional, in R from the project root: `install.packages("coda")` then
   `source("R/cross_check_coda.R")`

To run one piece, e.g. `run('scripts/run_02_scaling_acceptance.m')`.

## Project structure

```
src/                       sampler, diagnostics and model functions
  mh_sampler.m             random-walk Metropolis
  gibbs_bivariate.m        Gibbs sampler for a bivariate normal
  parallel_tempering.m     replica-exchange sampler
  autocorr_fft.m, iact.m, ess.m, rhat.m     diagnostics
  nig_posterior.m          exact conjugate regression posterior
  log_post_regression.m    log posterior used by Metropolis
scripts/                   four experiments and run_all.m
tests/run_tests.m          unit tests with known answers
R/cross_check_coda.R       cross-check of ESS and R-hat with coda
reports/report.md          theorems, proofs, experiments and limitations
results/                   generated tables and figures
```

## Limitations

- The CLT for Markov chains, the diffusion limit behind the 0.234 rule and the
  properties of R-hat are cited, not proved
- The 0.234 rule is asymptotic and can be a poor guide for skewed or strongly
  dependent targets
- ESS estimation is noisy for short chains; targets are low-dimensional with
  known answers; the tempering ladder was tuned by hand
